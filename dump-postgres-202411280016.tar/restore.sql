--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United Kingdom.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: impacto; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.impacto AS ENUM (
    'Baixo',
    'Médio',
    'Alto'
);


ALTER TYPE public.impacto OWNER TO postgres;

--
-- Name: sistema_rpg; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.sistema_rpg AS ENUM (
    'DND5e',
    'DND3e',
    'Tormenta',
    'Storyteller'
);


ALTER TYPE public.sistema_rpg OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: campanha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.campanha (
    id integer NOT NULL,
    nome character varying(50),
    mestre character varying(50),
    data_inicio date,
    sistema public.sistema_rpg NOT NULL
);


ALTER TABLE public.campanha OWNER TO postgres;

--
-- Name: campanha_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.campanha_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.campanha_id_seq OWNER TO postgres;

--
-- Name: campanha_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.campanha_id_seq OWNED BY public.campanha.id;


--
-- Name: eventos_marcantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eventos_marcantes (
    id integer NOT NULL,
    id_campanha integer,
    id_sessao integer,
    impacto public.impacto NOT NULL,
    nome character varying(50)
);


ALTER TABLE public.eventos_marcantes OWNER TO postgres;

--
-- Name: eventos_marcantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.eventos_marcantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eventos_marcantes_id_seq OWNER TO postgres;

--
-- Name: eventos_marcantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.eventos_marcantes_id_seq OWNED BY public.eventos_marcantes.id;


--
-- Name: participacaosessao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.participacaosessao (
    id_sessao integer NOT NULL,
    id_personagem integer NOT NULL
);


ALTER TABLE public.participacaosessao OWNER TO postgres;

--
-- Name: personagens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personagens (
    id integer NOT NULL,
    id_campanha integer,
    nome character varying(50),
    classe character varying(50),
    raca character varying(50)
);


ALTER TABLE public.personagens OWNER TO postgres;

--
-- Name: personagens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personagens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personagens_id_seq OWNER TO postgres;

--
-- Name: personagens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personagens_id_seq OWNED BY public.personagens.id;


--
-- Name: players; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.players (
    id integer NOT NULL,
    id_personagem integer,
    id_campanha integer,
    nome character varying(50)
);


ALTER TABLE public.players OWNER TO postgres;

--
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.players_id_seq OWNER TO postgres;

--
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- Name: sessao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessao (
    id integer NOT NULL,
    id_campanha integer,
    data_sessao date,
    hora_sessao time without time zone
);


ALTER TABLE public.sessao OWNER TO postgres;

--
-- Name: sessao_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sessao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessao_id_seq OWNER TO postgres;

--
-- Name: sessao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sessao_id_seq OWNED BY public.sessao.id;


--
-- Name: campanha id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campanha ALTER COLUMN id SET DEFAULT nextval('public.campanha_id_seq'::regclass);


--
-- Name: eventos_marcantes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eventos_marcantes ALTER COLUMN id SET DEFAULT nextval('public.eventos_marcantes_id_seq'::regclass);


--
-- Name: personagens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personagens ALTER COLUMN id SET DEFAULT nextval('public.personagens_id_seq'::regclass);


--
-- Name: players id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- Name: sessao id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessao ALTER COLUMN id SET DEFAULT nextval('public.sessao_id_seq'::regclass);


--
-- Data for Name: campanha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.campanha (id, nome, mestre, data_inicio, sistema) FROM stdin;
\.
COPY public.campanha (id, nome, mestre, data_inicio, sistema) FROM '$$PATH$$/4842.dat';

--
-- Data for Name: eventos_marcantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eventos_marcantes (id, id_campanha, id_sessao, impacto, nome) FROM stdin;
\.
COPY public.eventos_marcantes (id, id_campanha, id_sessao, impacto, nome) FROM '$$PATH$$/4849.dat';

--
-- Data for Name: participacaosessao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.participacaosessao (id_sessao, id_personagem) FROM stdin;
\.
COPY public.participacaosessao (id_sessao, id_personagem) FROM '$$PATH$$/4847.dat';

--
-- Data for Name: personagens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personagens (id, id_campanha, nome, classe, raca) FROM stdin;
\.
COPY public.personagens (id, id_campanha, nome, classe, raca) FROM '$$PATH$$/4844.dat';

--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.players (id, id_personagem, id_campanha, nome) FROM stdin;
\.
COPY public.players (id, id_personagem, id_campanha, nome) FROM '$$PATH$$/4851.dat';

--
-- Data for Name: sessao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessao (id, id_campanha, data_sessao, hora_sessao) FROM stdin;
\.
COPY public.sessao (id, id_campanha, data_sessao, hora_sessao) FROM '$$PATH$$/4846.dat';

--
-- Name: campanha_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.campanha_id_seq', 5, true);


--
-- Name: eventos_marcantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.eventos_marcantes_id_seq', 5, true);


--
-- Name: personagens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personagens_id_seq', 5, true);


--
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.players_id_seq', 5, true);


--
-- Name: sessao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sessao_id_seq', 5, true);


--
-- Name: campanha campanha_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.campanha
    ADD CONSTRAINT campanha_pkey PRIMARY KEY (id);


--
-- Name: eventos_marcantes eventos_marcantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eventos_marcantes
    ADD CONSTRAINT eventos_marcantes_pkey PRIMARY KEY (id);


--
-- Name: participacaosessao participacaosessao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participacaosessao
    ADD CONSTRAINT participacaosessao_pkey PRIMARY KEY (id_sessao, id_personagem);


--
-- Name: personagens personagens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personagens
    ADD CONSTRAINT personagens_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: sessao sessao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessao
    ADD CONSTRAINT sessao_pkey PRIMARY KEY (id);


--
-- Name: eventos_marcantes eventos_marcantes_id_campanha_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eventos_marcantes
    ADD CONSTRAINT eventos_marcantes_id_campanha_fkey FOREIGN KEY (id_campanha) REFERENCES public.campanha(id) ON DELETE CASCADE;


--
-- Name: eventos_marcantes eventos_marcantes_id_sessao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eventos_marcantes
    ADD CONSTRAINT eventos_marcantes_id_sessao_fkey FOREIGN KEY (id_sessao) REFERENCES public.sessao(id) ON DELETE CASCADE;


--
-- Name: participacaosessao participacaosessao_id_personagem_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participacaosessao
    ADD CONSTRAINT participacaosessao_id_personagem_fkey FOREIGN KEY (id_personagem) REFERENCES public.personagens(id) ON DELETE CASCADE;


--
-- Name: participacaosessao participacaosessao_id_sessao_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participacaosessao
    ADD CONSTRAINT participacaosessao_id_sessao_fkey FOREIGN KEY (id_sessao) REFERENCES public.sessao(id) ON DELETE CASCADE;


--
-- Name: personagens personagens_id_campanha_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personagens
    ADD CONSTRAINT personagens_id_campanha_fkey FOREIGN KEY (id_campanha) REFERENCES public.campanha(id) ON DELETE CASCADE;


--
-- Name: players players_id_campanha_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_id_campanha_fkey FOREIGN KEY (id_campanha) REFERENCES public.campanha(id) ON DELETE CASCADE;


--
-- Name: players players_id_personagem_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_id_personagem_fkey FOREIGN KEY (id_personagem) REFERENCES public.personagens(id) ON DELETE CASCADE;


--
-- Name: sessao sessao_id_campanha_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessao
    ADD CONSTRAINT sessao_id_campanha_fkey FOREIGN KEY (id_campanha) REFERENCES public.campanha(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

